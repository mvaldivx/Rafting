import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Start extends WindowAdapter {
JFrame principal;
TextField usr;
Label usu;
JButton btn,ext;
ImageIcon btninicio,btnexit;

	public Start(){
		principal = new JFrame("Figuras");
		usr = new TextField("");
		usu= new Label("Ingrese usuario");
		btninicio= new ImageIcon("\\java\\imagenes\\next.png");
		btn = new JButton(btninicio);
		btnexit= new ImageIcon("\\java\\imagenes\\delete.png");
		ext = new JButton(btnexit);

		
		//btn.setOpaque(false);
		//btn.setContentAreaFilled(false);
		//btn.setBorderPainted(false);
		btn.setBorder(null);
		ext.setOpaque(false);
		//ext.setContentAreaFilled(false);
		//ext.setBorderPainted(false);
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		principal.setLocation(dim.width/2-principal.getSize().width/2-300, dim.height/2-principal.getSize().height/2-300);
		principal.setUndecorated(true);
		
		principal.setLayout(null);
		
		principal.add(usu);
		principal.add(usr);
		principal.add(btn);
		principal.add(ext);
		
		usu.setBounds(250, 175, 200, 50);
		usr.setBounds(250, 225, 200, 25);
		btn.setBounds(300, 350, 100, 100);
		ext.setBounds(585,10,50,50);
		
		principal.setSize(700,600);
		principal.getContentPane().setBackground(new Color(42,121,129));
		principal.setVisible(true);
	}

	public void windowClosing(WindowEvent e){
	     principal.dispose();
	     principal=null;
	   } 
	
	
	public static void main(String[] args) {
		Start obj = new Start();

	}

}
