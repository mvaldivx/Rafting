import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Principal implements ActionListener {
	JFrame principal;
	TextField usr;
	JButton btn,ext,titu,usu;
	ImageIcon btninicio,btnexit,tit,usui;
	
       public Principal(){
    	   principal = new JFrame("Figuras");
   		usr = new TextField("");
   		btninicio= new ImageIcon("\\java\\imagenes\\Proyecto\\next.png");
   		btn = new JButton(btninicio);
   		btnexit= new ImageIcon("\\java\\imagenes\\Proyecto\\rsz_delete.png");
   		ext = new JButton(btnexit);
   		tit= new ImageIcon("\\java\\imagenes\\Proyecto\\titulo.png");
   		titu= new JButton(tit);
   		usui= new ImageIcon("\\java\\imagenes\\Proyecto\\Usuario.png");
   		usu= new JButton(usui);

   		
   		btn.setOpaque(false);
   		btn.setContentAreaFilled(false);
   		btn.setBorder(null);
   		ext.setOpaque(false);
   		ext.setContentAreaFilled(false);
   		ext.setBorderPainted(false);
   		titu.setOpaque(false);
   		titu.setContentAreaFilled(false);
   		titu.setBorderPainted(false);
   		usu.setOpaque(false);
   		usu.setContentAreaFilled(false);
   		usu.setBorderPainted(false);
   		
   		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
   		principal.setLocation(dim.width/2-principal.getSize().width/2-300, dim.height/2-principal.getSize().height/2-300);
   		principal.setUndecorated(true);
   		
   		principal.setLayout(null);
   		
   		principal.add(titu);
   		principal.add(usu);
   		principal.add(usr);
   		principal.add(btn);
   		principal.add(ext);
   		
   		usu.setBounds(250, 220, 225, 100);
   		usr.setBounds(250, 320, 200, 25);
   		btn.setBounds(300, 450, 100, 100);
   		ext.setBounds(630,10,48,48);
   		titu.setBounds(150,50,400,200);
   		
   		principal.setSize(700,600);
   		principal.getContentPane().setBackground(new Color(42,121,129));
   		principal.setVisible(true);
   		
   		ext.addActionListener(this);
   		btn.addActionListener(this);
   		
       }

       
   	public void sig(){
   		Levels obj = new Levels();
   	}
       public void actionPerformed(ActionEvent e) {
   		if(e.getSource().equals(ext))
           	System.exit(0);
   		else if(e.getSource().equals(btn))
			principal.setVisible(false);
   		    principal=null;
   			sig();
   		
   	}


	public void setvisible(boolean b) {
		if(b==true)
		    principal.setVisible(true);
		else{
			principal.dispose();}
		
	}
}
