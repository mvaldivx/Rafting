import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.*;
public class Game {
JFrame game;
JButton paus,fig1,fig2,fig3,fig4,pant;
ImageIcon pa,fi1,fi2,fi3,fi4,pan;

      public Game(){
    	  game=new JFrame();
    	  pa= new ImageIcon("\\java\\imagenes\\Proyecto\\pause.png");
    	  paus = new JButton(pa);
    	  pan = new ImageIcon("\\java\\imagenes\\Proyecto\\SQ.png");
    	  pant= new JButton(pan);
    	  fi1= new ImageIcon("\\java\\imagenes\\Proyecto\\cuadro.png");
    	  fig1 = new JButton(fi1);
    	  fi2 = new ImageIcon("\\java\\imagenes\\Proyecto\\circulo.png");
    	  fig2= new JButton(fi2);
    	  fi3 = new ImageIcon("\\java\\imagenes\\Proyecto\\triangulo.png");
    	  fig3= new JButton(fi3);
    	  fi4 = new ImageIcon("\\java\\imagenes\\Proyecto\\rectan.png");
    	  fig4= new JButton(fi4);
    	  
    	  
    	  Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
     		game.setLocation(dim.width/2-game.getSize().width/2-300, dim.height/2-game.getSize().height/2-300);
     		game.setUndecorated(true);
     		
     		paus.setOpaque(false);
       		paus.setContentAreaFilled(false);
       		paus.setBorder(null);
       		pant.setOpaque(false);
       		pant.setContentAreaFilled(false);
       		pant.setBorderPainted(false);
       		fig1.setOpaque(false);
       		fig1.setContentAreaFilled(false);
       		fig1.setBorderPainted(false);
       		fig2.setOpaque(false);
       		fig2.setContentAreaFilled(false);
       		fig2.setBorderPainted(false);
       		fig3.setOpaque(false);
       		fig3.setContentAreaFilled(false);
       		fig3.setBorderPainted(false);
       		fig4.setOpaque(false);
       		fig4.setContentAreaFilled(false);
       		fig4.setBorderPainted(false);
     		
     		game.setLayout(null);
     		
     		game.add(paus);
     		game.add(pant);
     		game.add(fig1);
     		game.add(fig2);
     		game.add(fig3);
     		game.add(fig4);
     		
     		paus.setBounds(10, 10, 33, 33);
     		pant.setBounds(240, 100, 260, 130);
     		fig1.setBounds(35, 380, 90, 89);
     		fig2.setBounds(195,380,98,98);
     		fig3.setBounds(345,380,104,98);
     		fig4.setBounds(495,380,180,90);
     		
     		game.setSize(700,600);
     		game.getContentPane().setBackground(new Color(42,121,129));
     		game.setVisible(true);
      }
}
