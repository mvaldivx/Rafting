import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Loadinga extends JFrame{
	ImageIcon prelo;
	JLabel preload;
	
	    public Loadinga(){
			waiting();
			
	         prelo = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Preloader.gif")).getImage());
             preload = new JLabel();
             preload.setIcon(prelo);
             
			
			Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	   		setLocation(dim.width/2-getSize().width/2-300, dim.height/2-getSize().height/2-300);
	   		setUndecorated(true);
			
	   		add(preload);
	   		preload.setBounds(200, 300, 400, 400);
	    	add(new Loading());
	    	setSize(700,600);
	    	setVisible(true);
	    }final Runnable tarea = new Runnable() {
			public void run() {
				 while (!Thread.currentThread().isInterrupted()) {

						Principal principal=new Principal();
						dispose();
			          try {
			              Thread.sleep(1000);
			          } catch (InterruptedException e) {
			              // good practice
			              Thread.currentThread().interrupt();
			              return;
			          }
			      }
			}
				};
	    public void waiting(){
			
	        ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor();
	        timer.scheduleAtFixedRate(tarea, 10, 10, TimeUnit.SECONDS);
	      
		}
}
