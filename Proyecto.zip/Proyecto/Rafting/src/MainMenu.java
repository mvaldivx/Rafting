
public class MainMenu  {

	public MainMenu(){
		load();
	}

   	public void load(){
   		Loadinga loadi=new Loadinga();
   	}
	
	public static void main(String[] args) {
		MainMenu obj = new MainMenu();

	}

	

}
