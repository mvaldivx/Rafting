import java.io.*;
public class Guardar implements Serializable{
String pre,re1,re2,re3,cor;
public Guardar(String pre,String re1,String re2,String re3,String cor){
this.pre=pre;
this.re1=re1;
this.re2=re2;
this.re3=re3;
this.cor=cor;
}
public String muestra(){
	String preg;
	System.out.println("Pregunta: " + pre);
	System.out.println("respuesta 1: " + re1);
  preg=pre+" "+ re1+ " " + re2 +" " +re3 +" " +cor;
return preg;

}
}