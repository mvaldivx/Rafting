import java.awt.Button;
import java.awt.Choice;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import javax.swing.JFrame;

public class Mostrar implements ActionListener, ItemListener {
JFrame f1;
Label lb1,lb2,lb3,lb4,lb5,pre1,rs1,rs2,rs3,corr;
Button accept;
String preg;
String[]pregunta;
Guardar tmp=null;
FileInputStream fis=null; 
FileOutputStream fos=null;
ObjectInputStream ois=null; 
ObjectOutputStream oos=null;
Vector <Guardar>v=new Vector<Guardar>();
int e=0,opc; double d=0.0; String cad=null;
int fin;
Choice preguntan;
	
	
	public Mostrar(String titulo, String lab){
		   f1 = new JFrame(titulo);
		   lb1= new Label(lab);
		  preguntan = new Choice();
		   lb2= new Label("Pregunta");
		   pre1=new Label();
			lb3= new Label("Respuesta 1: ");
			rs1=new Label();
			lb4= new Label("Respuesta 2: ");
			rs2= new Label();
			lb5= new Label("Respuesta 3: ");
			rs3=new Label();
		   accept= new Button("Aceptar");
		   
		   f1.setLayout(new FlowLayout());
		   
		   
		   f1.add(lb1);
		   f1.add(lb2);
		   f1.add(preguntan);
		   f1.add(pre1);
		   f1.add(lb3);
		   f1.add(rs1);
		   f1.add(lb4);
		   f1.add(rs2);
		   f1.add(lb5);
		   f1.add(rs3);
		   f1.add(accept);


		   lb1.setBounds(300, 50, 100, 10);
		   lb2.setBounds(70, 100, 100, 10);
		   pre1.setBounds(170, 100, 100, 10);
		   lb3.setBounds(70, 150, 100, 10);
		   rs1.setBounds(170, 150, 100, 10);
		   lb4.setBounds(70, 180, 100, 10);
		   rs2.setBounds(170, 180, 100, 10);
		   lb5.setBounds(70, 230, 100, 10);
		   rs3.setBounds(170, 230, 100, 10);
		   
		   f1.setSize(700,400);
		   f1.setVisible(true);
		   accept.addActionListener(this);
		   preguntan.addItemListener(this);
		   leer();
		
	}
	
	
	
	
	public void leer(){
		
	try{
         fis = new FileInputStream("objetos.dat");
         ois = new ObjectInputStream(fis);
         v = (Vector)ois.readObject();
        fis.close();
      }catch(IOException E){ }
       catch(ClassNotFoundException E){ }  
	 do{
              tmp=(Guardar)v.get(e);
              preg=preg + tmp.muestra();
              e++; 
	  }while(e<v.size());
	  e= v.size();
	 numberOfChoice();
	}

	public void muestrar(){
		pre1.setText(pregunta[0]);
		rs1.setText(pregunta[1]);
		rs2.setText(pregunta[2]);
		rs3.setText(pregunta[3]);
		
	}

	public void numberOfChoice(){
		String g;
		int o=0;
		 for(int i=1; i <= e; i++){
			 o=i;
			g=String.valueOf(o);
			 preguntan.add(g);
		 }
	}
	public void actionPerformed(ActionEvent e) {
		
	}


	public void itemStateChanged(ItemEvent e) {
		preg="";
		tmp=(Guardar)v.get(preguntan.getSelectedIndex());
        preg=preg + tmp.muestra();
    	pregunta=preg.split(" ");
		 muestrar();
	}
}
