import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

import javax.swing.JFrame;

public class Mostrar implements ActionListener, ItemListener {
JFrame f1;
Label lb1,lb2,lb3,lb4,lb5,pre1,rs1,rs2,rs3,corr;
Button accept,modify;
CheckboxGroup cbg1;
Checkbox cb1,cb2,cb3;
String preg;
String[]pregunta;
Guardar tmp=null;
FileInputStream fis=null; 
FileOutputStream fos=null;
ObjectInputStream ois=null; 
ObjectOutputStream oos=null;
Vector <Guardar>v=new Vector<Guardar>();
int e=0,opc; double d=0.0; String cad=null;
int fin;
Choice preguntan;
	
	
	public Mostrar(String titulo, String lab){
		f1 = new JFrame(titulo);
		lb1= new Label(lab);
		preguntan = new Choice();
		lb2= new Label("Pregunta");
		pre1=new Label();
		lb3= new Label("Respuesta 1: ");
		rs1=new Label();
		lb4= new Label("Respuesta 2: ");
		rs2= new Label();
		lb5= new Label("Respuesta 3: ");
		rs3=new Label();
        modify= new Button("Modificar");
		cbg1= new CheckboxGroup();
		cb1 = new Checkbox("",false,cbg1);
		cb2 = new Checkbox("",false,cbg1);
		cb3 = new Checkbox("",false,cbg1);
		accept= new Button("Aceptar");
		   
		f1.setLayout(null);
		   
		preguntan.add(" ");
		f1.add(lb1);
		f1.add(lb2);
		f1.add(preguntan);
		f1.add(pre1);
		f1.add(cb1);
		f1.add(lb3);
		f1.add(rs1);
		f1.add(cb2);
		f1.add(lb4);
		f1.add(rs2);
		f1.add(cb3);
		f1.add(lb5);
		f1.add(rs3);
		f1.add(modify);
		f1.add(accept);


		lb1.setBounds(300, 50, 100, 10);
		lb2.setBounds(70, 100, 100, 10);
		preguntan.setBounds(300,70,20,20);
		pre1.setBounds(170, 100, 100, 10);
		lb3.setBounds(70, 150, 100, 10);
		rs1.setBounds(170, 150, 100, 10);
		cb1.setBounds(200, 150, 30, 10);
		lb4.setBounds(70, 180, 100, 10);
		rs2.setBounds(170, 180, 100, 10);
		cb2.setBounds(200, 180, 30, 10);
		lb5.setBounds(70, 230, 100, 10);
		rs3.setBounds(170, 230, 100, 10);
		cb3.setBounds(200, 230, 30, 10);
		modify.setBounds(400,200,50,50);
	   
		f1.setSize(600,600);
	    f1.setBackground(new Color(59,106,176));
	   f1.setVisible(true);
	   accept.addActionListener(this);
	   modify.addActionListener(this);
	   preguntan.addItemListener(this);
	   leer();
		
	}
	
	
	
	
	public void leer(){
		
	try{
         fis = new FileInputStream("objetos.dat");
         ois = new ObjectInputStream(fis);
         v = (Vector)ois.readObject();
        fis.close();
      }catch(IOException E){ }
       catch(ClassNotFoundException E){ }  
	 do{
              tmp=(Guardar)v.get(e);
              preg=preg + tmp.muestra();
              e++; 
	  }while(e<v.size());
	  e= v.size();
	 numberOfChoice();
	}

	public void muestrar(){
		pre1.setText(pregunta[0]);
		rs1.setText(pregunta[1]);
		rs2.setText(pregunta[2]);
		rs3.setText(pregunta[3]);
		if(pregunta[4].equals("cb1"))
			cb1.setState(true);
		else if(pregunta[4].equals("cb2"))
			cb2.setState(true);
		else if(pregunta[4].equals("cb3"))
			cb3.setState(true);
	}
	public void clean(){
		pre1.setText("");
		rs1.setText("");
		rs2.setText("");
		rs3.setText("");
		cb1.setState(false);
		cb2.setState(false);
		cb3.setState(false);
	}

	public void numberOfChoice(){
		String g;
		int o=0;
		 for(int i=1; i <= e; i++){
			 o=i;
			g=String.valueOf(o);
			
			 preguntan.add(g);
		 }
	}
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource().equals(modify)){
			String titulo= "Modificar";
			String lab= "Modificar Reactivo";
			NuevaPregunta np;
			np= new NuevaPregunta(titulo,lab,preg);
			f1.dispose();
		}
			
	}


	public void itemStateChanged(ItemEvent e) {
		preg="";
		if(preguntan.getSelectedIndex()==0)
			clean();
		else{
		tmp=(Guardar)v.get(preguntan.getSelectedIndex()-1);
        preg=preg + tmp.muestra();
    	pregunta=preg.split(" ");
		 muestrar();
		}
	}



}
