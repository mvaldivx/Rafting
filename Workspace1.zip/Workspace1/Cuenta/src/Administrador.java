import java.awt.*;
import java.awt.event.*;

import javax.swing.JOptionPane;

public class Administrador extends WindowAdapter implements ActionListener {
Frame f1;
Label lb1,lb2,lb3,lb4;
Button bt1,bt2,bt3,bt4;
String titulo,boton,lab;
boolean opt=false;


   public Administrador(){
	   f1 = new Frame("Administrador");
	   lb1= new Label("Nuevo reactivo o pregunta");
	   bt1= new Button("Entrar");
	   lb2= new Label("Modificar reactivo o pregunta");
	   bt2= new Button("Entrar");
	   lb3= new Label("Eliminar reactivo o pregunta");
	   bt3= new Button("Entrar");
	   lb4= new Label("Mostrar Reactivos");
	   bt4= new Button("Entrar");
	   
	   f1.setLayout(new FlowLayout());
	   
	   f1.add(lb1);
	   f1.add(bt1);
	   f1.add(lb2);
	   f1.add(bt2);
	   f1.add(lb3);
	   f1.add(bt3);
	   f1.add(lb4);
	   f1.add(bt4);
	   
	   f1.setSize(300,200);
	   f1.setVisible(true);
	   bt1.addActionListener(this);
	   bt2.addActionListener(this);
	   bt3.addActionListener(this);
	   bt4.addActionListener(this);
	   f1.addWindowListener(this);
   }

	public void windowClosing(WindowEvent e){
		f1.dispose();
		f1=null;
	   }

	public void actionPerformed(ActionEvent ev) {
		if(ev.getSource().equals(bt1)){
			titulo= "Nueva Pregunta";
			lab= "Agregar Pregunta";
			if(JOptionPane.showConfirmDialog(f1, "Una sola respuesta?: ","Nueva Pregunta",JOptionPane.YES_NO_OPTION)== JOptionPane.YES_OPTION)
				opt=true;
			NuevaPregunta preg = new NuevaPregunta(titulo,lab,opt);
			}
		else if(ev.getSource().equals(bt2)){
			titulo= "Modificar";
			lab= "Modificar Pregunta";
			opt=true;
			NuevaPregunta preg = new NuevaPregunta(titulo,lab,opt);
		}
		else if(ev.getSource().equals(bt4)){
			titulo= "Mostrar";
			lab= "Mostrar Reactivos";
			Mostrar preg = new Mostrar(titulo,lab);
		}
		
	} 
}
