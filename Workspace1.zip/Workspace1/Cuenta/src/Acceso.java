import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Acceso extends WindowAdapter implements ActionListener{

	Frame f;
	Button enter;
	Label user,contra;
	TextField us;
	JPasswordField pass;
	
	public Acceso(){
		f=new Frame("Inicie Sesion");
		user = new Label("Usuario : ");
		us = new TextField();
		contra = new Label("Contrase�a : ");
		pass = new JPasswordField(10);
		enter=new Button("Entrar");
		
		
	   f.setLayout(null);
	   
	   f.add(user);
	   f.add(us);
	   f.add(contra);
	   f.add(pass);
 	   f.add(enter);
 	   

		user.setBounds(250, 100, 100, 20);
		us.setBounds(250, 150, 100, 20);
		contra.setBounds(250, 200, 100, 20);
		pass.setBounds(250, 250, 100, 20);
		enter.setBounds(300, 300, 100, 20);
 	   
 	   f.addWindowListener(this);
 	   enter.addActionListener(this);
 	   
 	   f.setSize(600,600);
       f.setBackground(new Color(59,106,176));
 	   f.setVisible(true);


		
}
	public void evalua(String us3 , String pass){
		String contra="mau";
		String pass3="1234";
		if(us3.equals(contra) && pass.equals(pass3) ) {
			Administrador admin=new Administrador();
		}
		else{
			System.out.println("Contrase�a incorrecta" + us3);
			 JOptionPane.showMessageDialog(f, "Contrase�a incorrecta ");
			
		}
	}
	
	public void windowClosing(WindowEvent e){
	     System.exit(0);
	   } 
	
	public static void main(String[] args) {
		Acceso obj = new Acceso();
	}




	public void actionPerformed(ActionEvent e) {
		//String input = new String(pass.getPassword());
		String us2 = (String)us.getText();
		String pas;
		pas= String.valueOf(pass.getPassword());
		evalua(us2,pas);
		
	}
}
