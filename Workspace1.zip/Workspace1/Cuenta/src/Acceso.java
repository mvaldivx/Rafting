import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Acceso extends WindowAdapter implements ActionListener{

	Frame f;
	Button enter;
	Label user,contra;
	TextField us;
	JPasswordField pass;
	
	public Acceso(){
		f=new Frame("Inicie Sesion");
		user = new Label("Usuario : ");
		us = new TextField();
		contra = new Label("Contrase�a : ");
		pass = new JPasswordField(10);
		enter=new Button("Entrar");
		
		
	   f.setLayout(new FlowLayout());
	   f.setLayout(new GridLayout (10,1));
	   
	   f.add(user);
	   f.add(us);
	   f.add(contra);
	   f.add(pass);
 	   f.add(enter);
 	   
 	   f.addWindowListener(this);
 	   enter.addActionListener(this);
 	   
 	   f.setSize(400,400);
 	   f.setVisible(true);

		
}
	public void evalua(String us3 ){
		String contra="mau";
		String pass3="1234";
		if(us3 == "mau" ) {
			System.out.println("Contrase�a correcta" +us3);
		}
		else{
			System.out.println("Contrase�a incorrecta" + us3);
			 JOptionPane.showMessageDialog(f, "Contrase�a incorrecta : " + us3 + pass3);
			Administrador admin=new Administrador();
		}
	}
	
	public void windowClosing(WindowEvent e){
	     System.exit(0);
	   } 
	
	public static void main(String[] args) {
		Acceso obj = new Acceso();
	}




	public void actionPerformed(ActionEvent arg0) {
		//String input = new String(pass.getPassword());
		String us2 = (String)us.getText();
		evalua(us2);
		
	}
}
