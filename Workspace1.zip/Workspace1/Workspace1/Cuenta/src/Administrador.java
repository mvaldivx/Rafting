import java.awt.*;
import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Administrador extends WindowAdapter implements ActionListener {
JFrame f1;
JButton lb1,lb2,lb3,lb4,cerrar,usumas;
JLabel adm;
String titulo,boton,lab;
boolean opt=false;


   public Administrador(){
	   f1 = new JFrame("Administrador");
	   ImageIcon clo = new ImageIcon(new ImageIcon(getClass().getResource("\\Images\\Admin\\cerrar.png")).getImage());
	   cerrar= new JButton(clo);
	   ImageIcon usuamas = new ImageIcon(new ImageIcon(getClass().getResource("\\Images\\Admin\\usuarioMas.png")).getImage());
	   usumas= new JButton(usuamas);
		ImageIcon nuevo = new ImageIcon(new ImageIcon(getClass().getResource("\\Images\\Admin\\nuevoReactivo.png")).getImage());
	   lb1= new JButton(nuevo);
		ImageIcon modifi = new ImageIcon(new ImageIcon(getClass().getResource("\\Images\\Admin\\modificarReactivo.png")).getImage());
	   lb2= new JButton(modifi);
		ImageIcon elimi = new ImageIcon(new ImageIcon(getClass().getResource("\\Images\\Admin\\eliminarReactivo.png")).getImage());
	   lb3= new JButton(elimi);
		ImageIcon mos = new ImageIcon(new ImageIcon(getClass().getResource("\\Images\\Admin\\mostrarReactivos.png")).getImage());
	   lb4= new JButton(mos);
	   ImageIcon dm = new ImageIcon(new ImageIcon(getClass().getResource("\\Images\\Admin\\admin.png")).getImage());
	   adm= new JLabel(dm);
	   
	   
	   Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		f1.setLocation(dim.width/2-f1.getSize().width/2-300, dim.height/2-f1.getSize().height/2-300);
		
		f1.setUndecorated(true);
		
	   f1.setLayout(null);
	   
	   cerrar.setOpaque(false);
  	   cerrar.setContentAreaFilled(false);
  	   cerrar.setBorder(null);
  	   usumas.setOpaque(false);
	   usumas.setContentAreaFilled(false);
	   usumas.setBorder(null);
	   lb1.setOpaque(false);
  	   lb1.setContentAreaFilled(false);
  	   lb1.setBorder(null);
  	   lb2.setOpaque(false);
	   lb2.setContentAreaFilled(false);
	   lb2.setBorder(null);
	   lb3.setOpaque(false);
  	   lb3.setContentAreaFilled(false);
  	   lb3.setBorder(null);
  	   lb4.setOpaque(false);
	   lb4.setContentAreaFilled(false);
	   lb4.setBorder(null);
	   
	   f1.add(cerrar);
	   f1.add(usumas);
	   f1.add(adm);
	   f1.add(lb1);
	   f1.add(lb2);
	   f1.add(lb3);
	   f1.add(lb4);
	   
	   cerrar.setBounds(20,20,120,25);
	   usumas.setBounds(480,20,50,50);
	   adm.setBounds(130, 55, 290, 60);
	   lb1.setBounds(130, 140, 320,60);
	   lb2.setBounds(110, 220, 340,60);
	   lb3.setBounds(110, 300, 340,60);
	   lb4.setBounds(110, 380, 340,60);
	   
	   f1.setSize(550,500);
       f1.getContentPane().setBackground(new Color(78,181,206));
	   f1.setVisible(true);
	   cerrar.addActionListener(this);
	   usumas.addActionListener(this);
	   lb1.addActionListener(this);
	   lb2.addActionListener(this);
	   lb3.addActionListener(this);	
	   lb4.addActionListener(this);
	   f1.addWindowListener(this);
   }

	public void windowClosing(WindowEvent e){
		f1.dispose();
		f1=null;
	   }
	public void nuevoUsuario(){
		JFrame fNuevoUsu = new JFrame("Nuevo Usuario");
		JLabel titu = new JLabel("Nuevo Usuario");
		JLabel Usu= new JLabel("Usuario: ");
		JTextField Usua= new JTextField();
		JLabel contras= new JLabel("Contrase�a: ");
		JTextField contra= new JTextField();
		JLabel niv= new JLabel("Nivel: ");
		Choice nive= new Choice();
		JButton acept= new JButton("Acceptar");
		nive.add("1");
		nive.add("2");
		
		 Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		 fNuevoUsu.setLocation(dim.width/2-fNuevoUsu.getSize().width/2-300, dim.height/2-fNuevoUsu.getSize().height/2-300);
			
		 fNuevoUsu.setUndecorated(true);
			
		 fNuevoUsu.setLayout(null);
		
		 acept.setOpaque(false);
	  	 acept.setContentAreaFilled(false);
	  	 acept.setBorder(null);
	  	 
		
		fNuevoUsu.add(titu);
		fNuevoUsu.add(Usu);
		fNuevoUsu.add(Usua);
		fNuevoUsu.add(contras);
		fNuevoUsu.add(contra);
		fNuevoUsu.add(niv);
		fNuevoUsu.add(nive);
		fNuevoUsu.add(acept);
		
		 titu.setBounds(50,50,120,50);
		 Usu.setBounds(50,100,100,25);
		 Usua.setBounds(150, 100, 100, 25);
		 contras.setBounds(50, 150, 100,25);
		 contra.setBounds(150, 150, 100,25);
		 niv.setBounds(110, 300, 340,25);
		 nive.setBounds(110, 380, 340,25);
		 acept.setBounds(110, 380, 340,25);
		
		 fNuevoUsu.setSize(550,500);
		 fNuevoUsu.getContentPane().setBackground(new Color(78,181,206));
		 fNuevoUsu.setVisible(true);
		
	}

	public void actionPerformed(ActionEvent ev) {
		if(ev.getSource().equals(cerrar)){
			f1.dispose();
			Acceso access = new Acceso();
			}
		else if(ev.getSource().equals(lb1)){
			f1.dispose();
			NuevaPregunta preg = new NuevaPregunta(titulo,lab);
			}
		else if(ev.getSource().equals(lb2)){
			f1.dispose();
			titulo= "Modificar";
			lab= "Modificar Pregunta";
			opt=true;
			NuevaPregunta preg = new NuevaPregunta(titulo,lab);
		}else if(ev.getSource().equals(lb3)){
			f1.dispose();
			titulo= "Eliminar";
			lab= "Eliminar Reactivos";
			boolean del= true;
			Mostrar preg = new Mostrar(titulo,lab,del);
		}
		else if(ev.getSource().equals(lb4)){
			f1.dispose();
			titulo= "Mostrar";
			lab= "Mostrar Reactivos";
			boolean del= false;
			Mostrar preg = new Mostrar(titulo,lab,del);
		}
		else if(ev.getSource().equals(usumas)){
			nuevoUsuario();
		}
		
	} 
}
