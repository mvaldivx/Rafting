import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Principal implements ActionListener,MouseListener {
	
	JFrame principal;
	TextField usr;
	JButton btn,ext,titu,usu,podium;
	ImageIcon btninicio,btnexit,tit,usui;
	Records Rc;
	
       public Principal(){
    	   principal = new JFrame("Figuras");
   		usr = new TextField("");
   		
   		
   		
   		btninicio= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Principal\\next.png")).getImage());
   		btn = new JButton(btninicio);
   		btnexit= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Principal\\rsz_delete.png")).getImage());
   		ext = new JButton(btnexit);
   		tit= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Principal\\titulo.png")).getImage());
   		titu= new JButton(tit);
   		usui= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Principal\\Usuario.png")).getImage());
   		usu= new JButton(usui);
   		ImageIcon pod= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Principal\\podium.png")).getImage());
   		podium= new JButton(pod);


   		
   		btn.setOpaque(false);
   		btn.setContentAreaFilled(false);
   		btn.setBorder(null);
   		ext.setOpaque(false);
   		ext.setContentAreaFilled(false);
   		ext.setBorderPainted(false);
   		titu.setOpaque(false);
   		titu.setContentAreaFilled(false);
   		titu.setBorderPainted(false);
   		usu.setOpaque(false);
   		usu.setContentAreaFilled(false);
   		usu.setBorderPainted(false);
   		podium.setOpaque(false);
   		podium.setContentAreaFilled(false);
   		podium.setBorderPainted(false);
   		
   		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
   		principal.setLocation(dim.width/2-principal.getSize().width/2-300, dim.height/2-principal.getSize().height/2-300);
   		principal.setUndecorated(true);
   		
   		principal.setLayout(null);
   		
   		principal.add(titu);
   		principal.add(usu);
   		principal.add(usr);
   		principal.add(btn);
   		principal.add(ext);
   		principal.add(podium);
   		
   		usu.setBounds(250, 220, 225, 100);
   		usr.setBounds(250, 320, 200, 25);
   		btn.setBounds(300, 450, 100, 100);
   		ext.setBounds(630,10,48,48);
   		titu.setBounds(150,50,400,200);
   		podium.setBounds(550,450,80,60);
   		
   		try
        {
        principal.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
   		
   		principal.setSize(700,600);
   		principal.getContentPane().setBackground(new Color(42,121,129));
   		principal.setIconImage(new ImageIcon(getClass().getResource("\\imagenes\\iconRafting.png")).getImage());
   		principal.setVisible(true);
   		
   		podium.addActionListener(this);
   		ext.addActionListener(this);
   		btn.addActionListener(this);
   		principal.addMouseListener(this);
   		usu.addMouseListener(this);
   		usr.addMouseListener(this);
   		btn.addMouseListener(this);
   		ext.addMouseListener(this);
   		titu.addMouseListener(this);
   		podium.addMouseListener(this);
       }

       
   	public void sig(){
   		String Name=null;
   		Name=usr.getText();
   		Levels obj = new Levels(Name);
   	}
       public void actionPerformed(ActionEvent e) {
   		if(e.getSource().equals(ext))
           	System.exit(0);
   		else if(e.getSource().equals(btn))
   			if(usr.getText().equals("")){
   				JOptionPane.showMessageDialog(principal, "Ingrese usuario","Error",JOptionPane.ERROR_MESSAGE);
   			}else{
			principal.setVisible(false);
   		    principal=null;
   			sig();
   			}
   		else if(e.getSource().equals(podium)){
   			Rc= new Records();
   			principal.dispose();
   		}
   	}


	public void setvisible(boolean b) {
		if(b==true)
		    principal.setVisible(true);
		else{
			principal.dispose();}
		
	}


	@Override
	public void mouseClicked(MouseEvent arg0) {
		
		
	}


	@Override
	public void mouseEntered(MouseEvent arg0) {

	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		
		
	}


	@Override
	public void mousePressed(MouseEvent arg0) {
		try
        {
        principal.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor2.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		try
        {
        principal.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
	}
}
