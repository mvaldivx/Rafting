import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Records implements ActionListener,MouseListener{
JFrame record;
FileInputStream fis=null; FileOutputStream fos=null;
ObjectInputStream ois=null; ObjectOutputStream oos=null;
GuardaRecord tmp=null; //Clase serializable
Vector <GuardaRecord>v=new Vector<GuardaRecord>();
String Usuario,fechas,puntaje,preg;
int puntos,e=0,r=0;
DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
Date date = new Date();
//TextArea raiting;
JLabel Records,encabezado;
JButton Aceptar;
String[] titulo={"Usuario","Puntaje","Fecha"};
String pregunta[];
String[][] datos;
JTable table;


	public Records(String usuario,int puntos){
		this.Usuario=usuario;
		this.puntos=puntos;
		leerArchivo();
		nuevoRecord();
		mostrarRecords();
	}
	public Records(){
		leerArchivo();
		mostrarRecords();
	}
	public void Dibuja(){
		record= new JFrame("Records");
  	 
  	    ImageIcon sa= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\sala.png")).getImage());
		Records= new JLabel(sa);
  	    ImageIcon acept= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\aceptar.png")).getImage());
		Aceptar= new JButton(acept);
		table = new JTable(datos, titulo);
  	    ImageIcon enca= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\encabezado.png")).getImage());
        encabezado= new JLabel(enca);
		

  	  Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
   		record.setLocation(dim.width/2-record.getSize().width/2-300, dim.height/2-record.getSize().height/2-300);
   		
   		
   		record.setUndecorated(true);
   		
   		record.setLayout(null);
   		
   		try
        {
        record.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
   		

		Aceptar.setOpaque(false);
		Aceptar.setContentAreaFilled(false);
		Aceptar.setBorder(null);
		
   		record.add(encabezado);
   		record.add(Records);
   		record.add(Aceptar);
   		record.add(table);

   		encabezado.setBounds(150,70,450,50);
   		Records.setBounds(210, 30, 350, 75);
   		table.setBounds(150, 100, 450, 400);
   		Aceptar.setBounds(400, 510, 175, 50);
   		
   		Aceptar.addActionListener(this);
   		
   		encabezado.addMouseListener(this);
   		Aceptar.addMouseListener(this);
   		record.addMouseListener(this);
   		Records.addMouseListener(this);
   		table.addMouseListener(this);
   		
   		record.setIconImage(new ImageIcon(getClass().getResource("\\imagenes\\iconRafting.png")).getImage());
		record.setSize(700,600);
 		record.getContentPane().setBackground(new Color(42,121,129));
 		record.setVisible(true);

		
	}
	public void leerArchivo(){
		try{
			  fis = new FileInputStream("Records.dat");
			  ois = new ObjectInputStream(fis);
			  v = (Vector)ois.readObject();
			  fis.close();
		  	}catch(IOException E){ }
		  	catch(ClassNotFoundException E){ }
	}
	public void nuevoRecord(){
		fechas=String.valueOf(dateFormat.format(date));
		puntaje= String.valueOf(puntos);
		
		if(v.size()==0)
			v.add(new GuardaRecord(Usuario,puntaje,fechas));
		else
	        mayorMenor();
		  	try{ 
		  		fos=new FileOutputStream("Records.dat");
		  		oos=new ObjectOutputStream(fos);
		  		oos.writeObject(v); //guarda el objeto en el archivo
		  		fos.close();
		  	}catch(IOException E){ }  
	}
	public void mayorMenor(){
		boolean menor=false;
		do{
			preg=null;
			pregunta=null;
            tmp=(GuardaRecord)v.get(r);
            preg= tmp.muestra();
            pregunta=preg.split("�");
            
            if(puntos > Integer.valueOf(pregunta[1])){
            	v.add(r,new GuardaRecord(Usuario,puntaje,fechas));
            	r=v.size();
            	menor=false;
            }
            else  {
            	r++;
            menor=true;}
	  }while(r<v.size());
		if(menor)
			v.add(r,new GuardaRecord(Usuario,puntaje,fechas));
	}
	public void mostrarRecords(){
		if(v.size()<1){
			JOptionPane.showMessageDialog(record, "No se ah registrado ningun puntaje");
			Principal pr = new Principal();
		}
		else{
		datos= new String[v.size()][3];
		do{
			preg=null;
			pregunta=null;
            tmp=(GuardaRecord)v.get(e);
            preg= tmp.muestra();
            pregunta=preg.split("�");
            for(int columnx=0;columnx<3;columnx++){
            datos[e][columnx]=pregunta[columnx];
            }
            //raiting.append(preg+"\n");
            e++; 
	  }while(e<v.size());
		Dibuja();
		}
		
		

	}
	public void actionPerformed(ActionEvent arg0) {
		Principal pr= new Principal();
		record.dispose();
		record=null;
		
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		try
        {
        record.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor2.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		try
        {
        record.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
	}
}
