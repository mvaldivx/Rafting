
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class Levels implements ActionListener,MouseListener{
JFrame lev;
JButton eas,med,hrd,atrs;
ImageIcon ea,me,hr,atr;
int randomNum,time;
String Usuario;
int level;

     public Levels(String usuario){
    	 this.Usuario=usuario;
    	 lev = new JFrame("Figuras");
    	 
    	ea= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Levels\\Facil.png")).getImage());
 		eas = new JButton(ea);
 		me= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Levels\\Medio.png")).getImage());
		med = new JButton(me);
		hr= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Levels\\Dificil.png")).getImage());
		hrd = new JButton(hr);
		atr= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Levels\\atras.png")).getImage());
		atrs = new JButton(atr);
		
		
		eas.setOpaque(false);
		eas.setContentAreaFilled(false);
		eas.setBorder(null);
		med.setOpaque(false);
		med.setContentAreaFilled(false);
		med.setBorder(null);
		hrd.setOpaque(false);
		hrd.setContentAreaFilled(false);
		hrd.setBorder(null);
		atrs.setOpaque(false);
		atrs.setContentAreaFilled(false);
		atrs.setBorder(null);
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		lev.setLocation(dim.width/2-lev.getSize().width/2-300, dim.height/2-lev.getSize().height/2-300);
		lev.setUndecorated(true);
		
		lev.setLayout(null);
		
		try
        {
        lev.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
		
		lev.add(atrs);
		lev.add(eas);
		lev.add(med);
		lev.add(hrd);
		
		atrs.setBounds(10, 10, 80, 40);
		eas.setBounds(250, 180, 225, 125);
		med.setBounds(250, 300, 225, 120);
		hrd.setBounds(250, 420, 225, 120);
		
		lev.setIconImage(new ImageIcon(getClass().getResource("\\imagenes\\iconRafting.png")).getImage());
		lev.setSize(700,600);
		lev.getContentPane().setBackground(new Color(42,121,129));
		lev.setVisible(true);
		
		atrs.addActionListener(this);
		eas.addActionListener(this);
		med.addActionListener(this);
		hrd.addActionListener(this);
		
		lev.addMouseListener(this);
		atrs.addMouseListener(this);
		eas.addMouseListener(this);
		med.addMouseListener(this);
		hrd.addMouseListener(this);
		
     }
     public void Go(){
    	 randomNum = 1 + (int)(Math.random() * 4); 
    	 Game jug= new Game(randomNum,time,Usuario,level);
     }
     

	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(atrs)){
			Principal principal=new Principal();
			principal.setvisible(true);
			lev.dispose();			
		}else if(e.getSource().equals(eas)){
			lev.setVisible(false);
			lev=null;
			level=1;
			time=3000;
			Go();
		}else if(e.getSource().equals(med)){
				lev.setVisible(false);
				lev=null;
				level=2;
				time=2000;
				Go();
		}else if(e.getSource().equals(hrd)){
					lev.setVisible(false);
					lev=null;
					level=3;
					time=1000;
					Go();
		}

		
		
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		try
        {
        lev.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor2.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
		
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		try
        {
        lev.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("\\imagenes\\cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
		
	}
}
