import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.*;
public class Game implements ActionListener {
boolean run = true;
JFrame game;
JButton paus,fig1,fig2,fig3,fig4,pant,cron;
ImageIcon pa,fi1,fi2,fi3,fi4,pan,crono;
int randomN,time,randomN1,segundos;
JLabel crontext;
int contando=0,descendente,descendentediez,puntos=0;
ScheduledExecutorService timer;
String cronometro,Usuario;


      public Game(int random, int timen,String usuario){
    	  randomN=random;
    	  time=timen;
    	  this.Usuario=usuario;
    	  waiting();
    	  game=new JFrame();
    	  pa= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\pause.png")).getImage());
    	  paus = new JButton(pa);
    	  crono= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\crono.gif")).getImage());
    	  cron= new JButton(crono);
    	  crontext= new JLabel();
    	  crontext.setText(String.valueOf(timen));
    	  if(random==1)
    	      pan = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\SQ.png")).getImage());
    	  else if(random==2)
    		  pan = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\circle.png")).getImage());
    	  else if(random==3)
    		  pan = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\triangle.png")).getImage());
    	  else if(random==4)
    		  pan = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\rectangle.png")).getImage());
    	  pant= new JButton(pan);
    	  fi1= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\cuadro.png")).getImage());
    	  fig1 = new JButton(fi1);
    	  fi2 = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\circulo.png")).getImage());
    	  fig2= new JButton(fi2);
    	  fi3 = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\triangulo.png")).getImage());
    	  fig3= new JButton(fi3);
    	  fi4 = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\rectan.png")).getImage());
    	  fig4= new JButton(fi4);
    	  
    	  
    	  Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
     		game.setLocation(dim.width/2-game.getSize().width/2-300, dim.height/2-game.getSize().height/2-300);
     		
     		
     		game.setUndecorated(true);
     		
     		paus.setOpaque(false);
       		paus.setContentAreaFilled(false);
       		paus.setBorder(null);
       		cron.setOpaque(false);
       		cron.setContentAreaFilled(false);
       		cron.setBorder(null);
       		pant.setOpaque(false);
       		pant.setContentAreaFilled(false);
       		pant.setBorderPainted(false);
       		fig1.setOpaque(false);
       		fig1.setContentAreaFilled(false);
       		fig1.setBorderPainted(false);
       		fig2.setOpaque(false);
       		fig2.setContentAreaFilled(false);
       		fig2.setBorderPainted(false);
       		fig3.setOpaque(false);
       		fig3.setContentAreaFilled(false);
       		fig3.setBorderPainted(false);
       		fig4.setOpaque(false);
       		fig4.setContentAreaFilled(false);
       		fig4.setBorderPainted(false);
     		
     		game.setLayout(null);
     		
     		game.add(paus);
     		game.add(cron);
     		game.add(crontext);
     		game.add(pant);
     		game.add(fig1);
     		game.add(fig2);
     		game.add(fig3);
     		game.add(fig4);
     		
     		
     		paus.addActionListener(this);
     		fig1.addActionListener(this);
     		fig2.addActionListener(this);
     		fig3.addActionListener(this);
     		fig4.addActionListener(this);
     		
     		paus.setBounds(10, 10, 33, 33);
     		cron.setBounds(550,10,50,50);
     		crontext.setBounds(600, 20, 40, 20);
     		pant.setBounds(215, 100, 330, 130);
     		fig1.setBounds(35, 380, 90, 89);
     		fig2.setBounds(195,380,98,98);
     		fig3.setBounds(345,380,104,98);
     		fig4.setBounds(495,380,180,90);
     		
     		game.setAlwaysOnTop(true);
     		game.setSize(700,600);
     		game.getContentPane().setBackground(new Color(42,121,129));
     		game.setVisible(true);
      }
      
      
      
      final Runnable tarea = new Runnable() {
		public void run() {
			     if(contando < time){
				    contando++;
				if(descendente==descendentediez){
				    muestra();
				    descendentediez=descendentediez-10;
				}
		    	descendente--;
			   }else{
				   if(descendente<=0){
					   crontext.setText("0");
					   incorrecto();
						timer.shutdown();
				   }else{
				   //iguales();
				   System.out.println(randomN);
				   System.out.println(time);
				   time-=100;
				   image();
	        
				   contando=0;
				   descendente=time;
				   descendentediez=time-10;
				   }
				   
			   }
			
            
	         
			
		}

			};
			public void incorrecto(){
				game.setAlwaysOnTop(false);
				JOptionPane.showMessageDialog(null, "Respuesta incorrecta \n puntaje: " + puntos );
			    Records rc= new Records(Usuario,puntos);
			    game.dispose();
			}
			public void image(){
				if(randomN==1)
		        	  pant.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\SQ.png")).getImage()));
		    	  else if(randomN==2)
		    		  pant.setIcon( new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\circle.png")).getImage()));
		    	  else if(randomN==3)
		    		  pant.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\triangle.png")).getImage()));
		    	  else if(randomN==4)
		    		  pant.setIcon(pan = new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\Game\\rectangle.png")).getImage()));
			}
			public void muestra(){

				crontext.setText(String.valueOf(descendente));
			}
			
    
public void iguales(){

	randomN1=randomN;
	randomN = 1 + (int)(Math.random() * 4); 
	if(randomN1==randomN){
		randomN = 1 + (int)(Math.random() * 4);
		iguales();
	}
		
}

	public void waiting(){
		descendente=time;
        descendentediez=time-10;
		timer = Executors.newSingleThreadScheduledExecutor();
        timer.scheduleWithFixedDelay(tarea, 1, 1, TimeUnit.MILLISECONDS);
        
	}


	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(fig1)){
			if(randomN==1){
				puntos++;
				timer.shutdown();
				iguales();
				image();
				time-=50;
				waiting();
			}
			else{
				timer.shutdown();
				incorrecto();
			}
		}else if(e.getSource().equals(fig2)){
			if(randomN==2){
				puntos++;
				timer.shutdown();
				iguales();
				image();
				time-=50;
				waiting();
			}
			else{
				timer.shutdown();
				incorrecto();
			}
		}else if(e.getSource().equals(fig3)){
				if(randomN==3){
					puntos++;
					timer.shutdown();
					iguales();
					image();
					time-=50;
					waiting();
				}
				else{
					timer.shutdown();
					incorrecto();
				}
		}else if(e.getSource().equals(fig4)){
					if(randomN==4){
						puntos++;
						timer.shutdown();
						iguales();
						image();
						time-=50;
						waiting();
					}
					else{
						timer.shutdown();
						incorrecto();
					}
				}
	}
		
	
      
}
