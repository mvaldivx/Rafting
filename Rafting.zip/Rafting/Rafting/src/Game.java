import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.*;
public class Game implements ActionListener,MouseListener{
boolean run = true;
JFrame game,pauseGame;
JButton paus,fig1,fig2,fig3,fig4,pant,cron,continuar,exitAndSave,exit;
ImageIcon pa,fi1,fi2,fi3,fi4,pan,crono,icon;
int randomN,time,randomN1,segundos,level;
JLabel crontext;
int contando=0,descendente,descendentediez,puntos=0;
ScheduledExecutorService timer;
String cronometro,Usuario;
boolean equivocado=false;


      public Game(int random, int timen,String usuario,int level){
    	  this.level=level;
    	  randomN=random;
    	  time=timen;
    	  this.Usuario=usuario;
    	  waiting();
    	  game=new JFrame();
    	  pa= new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/pause.png")).getImage());
    	  paus = new JButton(pa);
    	  crono= new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/crono.gif")).getImage());
    	  cron= new JButton(crono);
    	  crontext= new JLabel();
    	  crontext.setText(String.valueOf(timen));
    	  if(random==1)
    	      pan = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/SQ.png")).getImage());
    	  else if(random==2)
    		  pan = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/circle.png")).getImage());
    	  else if(random==3)
    		  pan = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/triangle.png")).getImage());
    	  else if(random==4)
    		  pan = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/rectangle.png")).getImage());
    	  pant= new JButton(pan);
    	  fi1= new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/cuadro.png")).getImage());
    	  fig1 = new JButton(fi1);
    	  fi2 = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/circulo.png")).getImage());
    	  fig2= new JButton(fi2);
    	  fi3 = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/triangulo.png")).getImage());
    	  fig3= new JButton(fi3);
    	  fi4 = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/rectan.png")).getImage());
    	  fig4= new JButton(fi4);
    	  
    	  
    	  Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
     		game.setLocation(dim.width/2-game.getSize().width/2-300, dim.height/2-game.getSize().height/2-300);
     		
     		try
            {
            game.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("/imagenes/cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
            }catch(Exception e){}
     		
     		game.setUndecorated(true);
     		
     		paus.setOpaque(false);
       		paus.setContentAreaFilled(false);
       		paus.setBorder(null);
       		cron.setOpaque(false);
       		cron.setContentAreaFilled(false);
       		cron.setBorder(null);
       		pant.setOpaque(false);
       		pant.setContentAreaFilled(false);
       		pant.setBorderPainted(false);
       		fig1.setOpaque(false);
       		fig1.setContentAreaFilled(false);
       		fig1.setBorderPainted(false);
       		fig2.setOpaque(false);
       		fig2.setContentAreaFilled(false);
       		fig2.setBorderPainted(false);
       		fig3.setOpaque(false);
       		fig3.setContentAreaFilled(false);
       		fig3.setBorderPainted(false);
       		fig4.setOpaque(false);
       		fig4.setContentAreaFilled(false);
       		fig4.setBorderPainted(false);
     		
     		game.setLayout(null);
     		
     		game.add(paus);
     		game.add(cron);
     		game.add(crontext);
     		game.add(pant);
     		game.add(fig1);
     		game.add(fig2);
     		game.add(fig3);
     		game.add(fig4);
     		
     		
     		paus.addActionListener(this);
     		fig1.addActionListener(this);
     		fig2.addActionListener(this);
     		fig3.addActionListener(this);
     		fig4.addActionListener(this);
     		
     		game.addMouseListener(this);
     		paus.addMouseListener(this);
     		fig1.addMouseListener(this);
     		fig2.addMouseListener(this);
     		fig3.addMouseListener(this);
     		fig4.addMouseListener(this);
     		cron.addMouseListener(this);
     		crontext.addMouseListener(this);
     		pant.addMouseListener(this);
     		
     		paus.setBounds(10, 10, 33, 33);
     		cron.setBounds(550,10,50,50);
     		crontext.setBounds(600, 20, 40, 20);
     		pant.setBounds(215, 100, 330, 130);
     		fig1.setBounds(35, 380, 90, 89);
     		fig2.setBounds(195,380,98,98);
     		fig3.setBounds(345,380,104,98);
     		fig4.setBounds(495,380,180,90);
     		
     		game.setIconImage(new ImageIcon(getClass().getResource("/imagenes/iconRafting.png")).getImage());
     		game.setAlwaysOnTop(true);
     		game.setSize(700,600);
     		game.getContentPane().setBackground(new Color(42,121,129));
     		game.setVisible(true);
      }
      
      
      
      final Runnable tarea = new Runnable() {
		public void run() {
			     if(contando < time){
				    contando++;
				if(descendente==descendentediez){
				    muestra();
				    descendentediez=descendentediez-10;
				}
		    	descendente--;
			   }else{
				   if(descendente<=0){
					   crontext.setText("0");
					   incorrecto();
						timer.shutdown();
				   }else{
				   //iguales();
				   switch(level){
				   case 1:
					   time-=100;
					   break;
				   case 2:
					   time-=200;
					   break;
				   case 3: 
					   time-=300;
					   break;
				   }
				   
				   
				   image();
	        
				   contando=0;
				   descendente=time;
				   descendentediez=time-10;
			
				   
				   }
				   
			   }
			
            
	         
			
		}

			};
			public void incorrecto(){
				game.setAlwaysOnTop(false);
				if(equivocado)
				    JOptionPane.showMessageDialog(null, "Respuesta incorrecta \n puntaje: " + puntos );
			    Records rc= new Records(Usuario,puntos);
			    game.dispose();
			}
			public void image(){
				if(randomN==1)
		        	  pant.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/SQ.png")).getImage()));
		    	  else if(randomN==2)
		    		  pant.setIcon( new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/circle.png")).getImage()));
		    	  else if(randomN==3)
		    		  pant.setIcon(new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/triangle.png")).getImage()));
		    	  else if(randomN==4)
		    		  pant.setIcon(pan = new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/rectangle.png")).getImage()));
			}
			public void muestra(){

				crontext.setText(String.valueOf(descendente));
			}
			
    
public void iguales(){

	randomN1=randomN;
	randomN = 1 + (int)(Math.random() * 4); 
	if(randomN1==randomN){
		randomN = 1 + (int)(Math.random() * 4);
		iguales();
	}
		
}

	public void waiting(){
		descendente=time;
        descendentediez=time-10;
		timer = Executors.newSingleThreadScheduledExecutor();
        timer.scheduleWithFixedDelay(tarea, 1, 1, TimeUnit.MILLISECONDS);
        
	}
	public void Pause(){
		pauseGame= new JFrame();
		ImageIcon Titu= new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/pauseTitu.png")).getImage());
		JLabel tituloPaus = new JLabel(Titu);
		ImageIcon cont= new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/continuar.png")).getImage());
		continuar = new JButton(cont);
		ImageIcon exitand= new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/exitandSave.png")).getImage());
		exitAndSave = new JButton(exitand);
		ImageIcon exi= new ImageIcon(new ImageIcon(getClass().getResource("/imagenes/Game/exit.png")).getImage());
		exit = new JButton(exi);
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		pauseGame.setLocation(dim.width/2-pauseGame.getSize().width/2-200, dim.height/2-pauseGame.getSize().height/2-200);
		
		pauseGame.setUndecorated(true);
		
		pauseGame.setLayout(null);
		
		try
        {
        pauseGame.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("/imagenes/cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
		
		continuar.setOpaque(false);
		continuar.setContentAreaFilled(false);
		continuar.setBorder(null);
		exitAndSave.setOpaque(false);
		exitAndSave.setContentAreaFilled(false);
		exitAndSave.setBorder(null);
		exit.setOpaque(false);
		exit.setContentAreaFilled(false);
		exit.setBorder(null);
		
		pauseGame.add(tituloPaus);
		pauseGame.add(continuar);
		pauseGame.add(exitAndSave);
		pauseGame.add(exit);
		
		tituloPaus.setBounds(140,30,200,105);
		continuar.setBounds(110, 130, 280, 80);
		exitAndSave.setBounds(50, 220, 400, 80);
		exit.setBounds(40, 320, 450, 80);
		
		
		continuar.addActionListener(this);
		exit.addActionListener(this);
		exitAndSave.addActionListener(this);
		
		continuar.addMouseListener(this);
		pauseGame.addMouseListener(this);
		tituloPaus.addMouseListener(this);
		exit.addMouseListener(this);
		exitAndSave.addMouseListener(this);
		
		
		pauseGame.setAlwaysOnTop(true);
		pauseGame.setSize(500,400);
		pauseGame.getContentPane().setBackground(new Color(34,81,87));
		pauseGame.setVisible(true);
		
	}


	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(fig1)){
			if(randomN==1){
				puntos++;
				timer.shutdown();
				iguales();
				image();
				time-=50;
				waiting();
			}
			else{
				timer.shutdown();
				equivocado=true;
				incorrecto();
			}
		}else if(e.getSource().equals(fig2)){
			if(randomN==2){
				puntos++;
				timer.shutdown();
				iguales();
				image();
				time-=50;
				waiting();
			}
			else{
				timer.shutdown();
				equivocado=true;
				incorrecto();
			}
		}else if(e.getSource().equals(fig3)){
				if(randomN==3){
					puntos++;
					timer.shutdown();
					iguales();
					image();
					time-=50;
					waiting();
				}
				else{
					timer.shutdown();
					equivocado=true;
					incorrecto();
				}
		}else if(e.getSource().equals(fig4)){
					if(randomN==4){
						puntos++;
						timer.shutdown();
						iguales();
						image();
						time-=50;
						waiting();
					}
					else{
						timer.shutdown();
						equivocado=true;
						incorrecto();
					}
		}else if(e.getSource().equals(paus)){
			        game.enable(false);
			        timer.shutdown();
			        Pause();
				}
		else if(e.getSource().equals(continuar)){
	        game.enable(true);
            pauseGame.dispose();
			waiting();
		}
		else if(e.getSource().equals(exit)){
			timer.shutdown();
	        pauseGame.dispose();
	        game.dispose();
	        Principal pr = new Principal();
		}
		else if(e.getSource().equals(exitAndSave)){
			equivocado=false;
			pauseGame.dispose();
			timer.shutdown();
			incorrecto();
		}
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		try
        {
        game.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("/imagenes/cursor2.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		try
        {
        game.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("/imagenes/cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
        }catch(Exception e){}
	}
		
	
      
}
