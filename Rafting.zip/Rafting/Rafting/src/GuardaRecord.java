import java.io.*;
public class GuardaRecord implements Serializable{
String usu,puntos,fecha;
public GuardaRecord(String usu,String puntos,String fecha){
this.usu=usu;
this.puntos=puntos;
this.fecha=fecha;
}
public String muestra(){
	String preg;
  preg=usu+"�"+ puntos+ "�" + fecha+"�";
return preg;

}
}
