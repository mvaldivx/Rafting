import java.awt.Color;
import java.awt.Dimension;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Records implements ActionListener{
JFrame record;
FileInputStream fis=null; FileOutputStream fos=null;
ObjectInputStream ois=null; ObjectOutputStream oos=null;
GuardaRecord tmp=null; //Clase serializable
Vector <GuardaRecord>v=new Vector<GuardaRecord>();
String Usuario,fechas,puntaje,preg;
int puntos,e=0,r=0;
Date fecha = new Date();
//TextArea raiting;
JLabel Records;
JButton Aceptar;
String[] titulo={"Usuario","Puntaje","Fecha"};
String pregunta[];
String[][] datos;
JTable table;


	public Records(String usuario,int puntos){
		this.Usuario=usuario;
		this.puntos=puntos;
		nuevoRecord();
		mostrarRecords();
	}
	public void Dibuja(){
		record= new JFrame("Records");
  	    ImageIcon sa= new ImageIcon(new ImageIcon(getClass().getResource("\\imagenes\\sala.png")).getImage());
		Records= new JLabel(sa);
		Aceptar= new JButton("Aceptar");
		table = new JTable(datos, titulo);
		
		

  	  Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
   		record.setLocation(dim.width/2-record.getSize().width/2-300, dim.height/2-record.getSize().height/2-300);
   		
   		
   		record.setUndecorated(true);
   		
   		record.setLayout(null);
		
   		//record.add(raiting);
   		record.add(Records);
   		record.add(Aceptar);
   		record.add(table);

   		Records.setBounds(220, 30, 350, 75);
   		table.setBounds(150, 100, 450, 400);
   		Aceptar.setBounds(400, 500, 100, 50);
   		
   		Aceptar.addActionListener(this);
   		
		record.setSize(700,600);
 		record.getContentPane().setBackground(new Color(42,121,129));
 		record.setVisible(true);

		
	}
	public void nuevoRecord(){
		fechas=String.valueOf(fecha.getDay())+"/"+String.valueOf(fecha.getMonth())+"/"+String.valueOf(fecha.getYear());
		puntaje= String.valueOf(puntos);
		try{
			  fis = new FileInputStream("Records.dat");
			  ois = new ObjectInputStream(fis);
			  v = (Vector)ois.readObject();
			  fis.close();
		  	}catch(IOException E){ }
		  	catch(ClassNotFoundException E){ }
		if(v.size()==0)
			v.add(new GuardaRecord(Usuario,puntaje,fechas));
		else
	        mayorMenor();
		  	try{ 
		  		fos=new FileOutputStream("Records.dat");
		  		oos=new ObjectOutputStream(fos);
		  		oos.writeObject(v); //guarda el objeto en el archivo
		  		fos.close();
		  	}catch(IOException E){ }  
	}
	public void mayorMenor(){
		boolean menor=false;
		do{
			preg=null;
			pregunta=null;
            tmp=(GuardaRecord)v.get(r);
            preg= tmp.muestra();
            pregunta=preg.split("�");
            
            if(puntos > Integer.valueOf(pregunta[1])){
            	v.add(r,new GuardaRecord(Usuario,puntaje,fechas));
            	r=v.size();
            	menor=false;
            }
            else  {
            	r++;
            menor=true;}
	  }while(r<v.size());
		if(menor)
			v.add(r,new GuardaRecord(Usuario,puntaje,fechas));
	}
	public void mostrarRecords(){
		datos= new String[v.size()][3];
		do{
			preg=null;
			pregunta=null;
            tmp=(GuardaRecord)v.get(e);
            preg= tmp.muestra();
            pregunta=preg.split("�");
            for(int columnx=0;columnx<3;columnx++){
            datos[e][columnx]=pregunta[columnx];
            }
            //raiting.append(preg+"\n");
            e++; 
	  }while(e<v.size());
		Dibuja();

		

	}
	public void actionPerformed(ActionEvent arg0) {
		Principal pr= new Principal();
		record.dispose();
		record=null;
		
	}
}
