
public class Contador {

}
