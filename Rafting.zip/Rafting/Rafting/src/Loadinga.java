import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Loadinga extends JFrame{
	boolean run = true;
	int delay=5000;
	
	    public Loadinga(){
	    	timer.schedule(task, delay);
			
			Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
			
	   		setLocation(dim.width/2-getSize().width/2-300, dim.height/2-getSize().height/2-300);
	   		setUndecorated(true);
	   		
	   		try
	        {
	          setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon(getClass().getResource("/imagenes/cursor1.png")).getImage(), new Point(0, 0),"Cursor"));
	        }catch(Exception e){}
			
	   		setIconImage(new ImageIcon(getClass().getResource("/imagenes/iconRafting.png")).getImage());
	    	add(new Loading());
	    	setSize(700,600);
	    	setVisible(true);
	        run=false;
	    }
	    final Timer timer = new Timer();

        final TimerTask task = new TimerTask() {
            public void run() {
                	Principal principal=new Principal();
            		dispose();
                   timer.cancel();
                   timer.purge();
                
            }
        };

        
	    
}
